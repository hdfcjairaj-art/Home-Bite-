HOME BITE WEBSITE - MOBILE DEPLOYMENT

Upload index.html to a GitHub repository, then enable GitHub Pages:
1. Sign in at https://github.com in your mobile browser.
2. Create a new repository named home-bite (Public).
3. Upload index.html from this folder and commit the change.
4. Open repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait a few minutes. GitHub will show a public website URL like https://YOUR-USERNAME.github.io/home-bite/.

Important: This is a prototype. Orders are not stored in a server database and payment is not automatically verified. Check that the phone number, address, menu, and UPI details are correct before publishing.
