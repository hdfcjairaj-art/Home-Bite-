# Home Bite Android App Project

A small Android WebView app for the Home Bite tiffin service. The interface includes a tiffin menu, weekly/monthly plan options, customer details, quantity and total calculation, a UPI deep link, and WhatsApp order handoff.

## Business details configured
- Brand: Home Bite
- Owner: Arnav
- Address: 163, Wadha Nagar, Baltana, Zirakpur, Punjab
- Contact / WhatsApp: 9306474547
- UPI ID: 9306474547@upi

## Build an APK with Android Studio
1. Install the current stable Android Studio on a computer.
2. Open this `HomeBiteAndroid` folder using **File → Open**.
3. Allow Gradle sync and install the Android SDK platform requested by the project (compile SDK 35).
4. Use **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK will normally appear at `app/build/outputs/apk/debug/app-debug.apk`.
6. To publish on Google Play, create a signed Android App Bundle (`.aab`) using **Build → Generate Signed Bundle / APK** and follow current Play Console testing and policy requirements.

## Important limitations
- This is a prototype. Orders are handed off to WhatsApp; no order database, merchant dashboard, live delivery tracking, or server is included.
- The UPI button opens a compatible UPI app; it does not verify payment. Confirm orders and payment manually.
- Menu rates are sample prices as agreed in the conversation. Confirm plan billing, availability, delivery radius, privacy policy, and final prices before public release.
- The project source is provided; a compiled APK has not been produced in this environment because Android SDK/Gradle build tooling is not installed here.
