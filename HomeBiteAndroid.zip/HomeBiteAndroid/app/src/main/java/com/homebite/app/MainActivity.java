package com.homebite.app;
import android.app.*; import android.os.*; import android.webkit.*; import android.content.*; import android.net.*;
public class MainActivity extends Activity {
  WebView w;
  @Override public void onCreate(Bundle b){super.onCreate(b); w=new WebView(this); w.getSettings().setJavaScriptEnabled(true); w.getSettings().setDomStorageEnabled(true); w.setWebViewClient(new WebViewClient()); w.loadUrl("file:///android_asset/index.html"); setContentView(w);}
}
